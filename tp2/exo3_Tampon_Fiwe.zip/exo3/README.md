Dossier contenant le script de réponse au sujet proposé par kadoum pour la L3 Miashs.

Réalisé par Barros Lucas le 01/02/2019

Note: Script pas entierement fini, une amélioration est possible au nievau de la taille du TAMPON du pipe et qui permettrait d'afficher le contenu en entier dans le cas où le fichier est volumineux
